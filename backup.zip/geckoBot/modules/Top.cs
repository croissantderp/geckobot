﻿using System;

public class Top
{
    //token
    public static string secret = "NzY2MDY0NTA1MDc5NzI2MTQw.X4d7Kg.ep5kd-UlN0nQSlNAKCmDAl-IUfg";

    //password for force updating
    public static string Secret = "croissant2021";
}
