# geckobot

:lemonthink:

[trello](https://trello.com/b/cFS33M13/gecko-bot-todo)

[discord invite link](https://discord.com/oauth2/authorize?client_id=766064505079726140&scope=bot&permissions=379968) 
(warning: do not give this bot any more perms than the ones given by the link)
